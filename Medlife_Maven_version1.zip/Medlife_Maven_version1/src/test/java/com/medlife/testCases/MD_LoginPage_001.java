package com.medlife.testCases;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.medlife.pageObjects.LoginPage;

public class MD_LoginPage_001 extends BaseClass{
	
	@Test
	public void loginTest() throws Exception {
		
		
		/*
		 * 
		 * Navigating to url
		 * 
		 * */
		driver.get(baseURL);
		String u1 = driver.getCurrentUrl();
		if(u1.equals("https://www.medlife.com/")) {
			Assert.assertTrue(true);
			logger.info("Navigated to correct URL");
			
		}
		else {
			Assert.assertFalse(false);
			logger.info("Navigated to wrong URL");
		}
		
		LoginPage lp = new LoginPage(driver);
		

		/*
		 * UI first cross button
		 * 
		 */
		lp.firstClose();
		logger.info("Cross button is clicked");
		

		/*
		 * UI login button
		 * 
		 */
		lp.loginButton();
		logger.info("Login Button is clicked");
		

		/*
		 * Navigation to login page
		 * 
		 */
		Thread.sleep(3000);
	
		String u2 = driver.getCurrentUrl();
		if(u2.equals("https://www.medlife.com/Login")) {
			Assert.assertTrue(true);
			logger.info("Navigated to Login URL");
			
		}
		else {
			Assert.assertFalse(false);
			logger.info("Navigated to wrong URL");
		}
		
		/*
		 * entering the user name 
		 * 
		 */
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		lp.username(username);
		logger.info("Entered usrname");
		
		/*
		 * Entering the password
		 * 
		 */
		lp.password(password);
		logger.info("Entered password");
		
		/*
		 * Clicking on proceed button
		 * 
		 */
		lp.proceed();
		logger.info("Clicked on proceed button");
		
		
		Thread.sleep(3000);
		String a = null;
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		if(lp.logTitle(a).equals("Prakash")) {
			Assert.assertTrue(true);
			logger.info("Successful Login by user id =  "+lp.logTitle(a));
			
		}
		else {
			Assert.assertFalse(false);
			logger.info("Unsuccessful Login where user id = "+lp.logTitle(a));
		}
		
	}

}
