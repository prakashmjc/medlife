package com.medlife.testCases;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.medlife.utilities.ReadConfig;


public class BaseClass {
	
	ReadConfig readconfig = new ReadConfig();
	
	public String baseURL = readconfig.getApplicationUrl();
	public String username = readconfig.getUsername();
	public String password = readconfig.getPasswords();
	
	public static WebDriver driver;
	
	public static Logger logger;
	@Parameters("browser")
	@BeforeClass
	public void setup(String br) {
		
		if(br.equals("chrome")) {
			
			System.setProperty("webdriver.chrome.driver", readconfig.getChromepath());		
			driver = new ChromeDriver();
		
		}
		else if(br.equals("firefox")) 
		{
			System.setProperty("webdriver.chrome.driver", readconfig.getFirefoxpath());		
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		
		 logger = Logger.getLogger("Medlife");
		 PropertyConfigurator.configure("C:\\Z-Drive\\Eclipse\\Eclipse SecondLap\\Eclipse SecondLap\\Medlife_Maven_version1\\log\\Log4j.properties");
	}

	@AfterClass
	public void teardown() throws Exception {
		Thread.sleep(3000);
		driver.quit();
	}
}
