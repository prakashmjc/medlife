package com.medlife.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
		
	WebDriver ldriver;
	
	public LoginPage(WebDriver rdriver) {
		
		
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath="//div[@id='__next']/div[2]/div[1]/img")
	WebElement firstCloseBtn;
	
	@FindBy(xpath="//button[@class='dropdown-trigger']")
	WebElement loginButtonClick;
	
	@FindBy(xpath="//input[@name='mobilenumber']")
	@CacheLookup
	WebElement txtUsername;
	
	@FindBy(xpath="//input[@name='password']")
	@CacheLookup
	WebElement txtPassword;
	
	@FindBy(xpath="//button[@type='submit']")
	WebElement btnProceed;
	
	@FindBy(xpath="//div[@class='dd-header']/span")
	WebElement loginTitle;
	
	
	
	public void firstClose() {
		firstCloseBtn.click();
	}

	public void loginButton() {		
		loginButtonClick.click();		
	}
	
	public void username(String unme) {
		txtUsername.sendKeys(unme);
	}
	
	public void password(String passwrd) {
		txtPassword.sendKeys(passwrd);
		
	}
	public void proceed() {
		btnProceed.click();
	}
	
	public String logTitle(String txt) {
		
		String s = loginTitle.getText();
		return s;
	}
}
